## wx-shop 欢迎各位有志之士的到来，如果您觉得对您有帮助，还希望用您的发财的小手给个 star，不尽感激！
### 原生微信小程序电商项目，非常适合需要有实战项目的小伙伴学习 分为四个大的主要模块，首页，分类页，购物车，我的
### 如有什么需要可随时致电  664431710  qq微信同

### 第一个：首页
![](https://ae01.alicdn.com/kf/Hbcc09c4eebc74f369ad9c21cb1213947C.png)


### 第二个，分类页
![](https://ae01.alicdn.com/kf/H6e5cdf9f88e94153801a83c4583e8194c.png)

### 第三个：购物车 这是没有商品和没有收货地址的页面
![](https://ae01.alicdn.com/kf/Hc30e979851b94fc48cbbfcb4bd62e2a8s.png)


### 第四个 我的页面， 其中 有未登录时和登录时的页面，这个是登录时的页面
![](https://ae01.alicdn.com/kf/Hb76e93d7b50b43c4bfeddf039b323a9fX.png)

### 这个是搜索列表
![](https://ae01.alicdn.com/kf/H79cc633da88f42ff9b49a02d434ba77aF.png)

### 商品列表
![](https://ae01.alicdn.com/kf/Hb2d292ceddd4469f89304590860544acN.png)

### 购物车 
![](https://ae01.alicdn.com/kf/Ha6736999135f4b1588bb3472fbc5e50cY.png)

### 商品支付
![](https://ae01.alicdn.com/kf/H5825f21066f949e49ff5fe95d64949940.png)

### 如果有啥不足的地方，请各位大佬指来， 也可以加我微信一起学习，哈哈哈

![](https://ae01.alicdn.com/kf/H4c5eec6b185e4797ba2bc02218aaa1f2y.png)



